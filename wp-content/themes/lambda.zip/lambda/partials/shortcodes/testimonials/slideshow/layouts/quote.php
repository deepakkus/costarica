<blockquote <?php echo $min_height ?>>
    <p><?php echo strip_tags( get_the_content() ); ?></p>
</blockquote>
