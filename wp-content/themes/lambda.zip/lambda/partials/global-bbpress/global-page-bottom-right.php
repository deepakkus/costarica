            </div>
            <div class="col-md-3 sidebar">
                <?php
                if( is_active_sidebar( 'bbpress-sidebar' ) ) {
                    dynamic_sidebar( 'bbpress-sidebar' );
                }
                ?>
            </div>
        </div>
    </div>
</section>